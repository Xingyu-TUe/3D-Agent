/** Auto from manifest.json */
export default {
  "name": "Hell Rift Asset Pack",
  "version": "1.1.0",
  "style": "dark-gothic-topdown-original",
  "note": "原创程序化像素/矢量拼接素材，无第三方版权。俯视角、透明背景。",
  "palette": {
    "blood": "#b3121f",
    "ash": "#37343e",
    "bone": "#dcd2be",
    "lava": "#ff781e",
    "gold": "#ffcd46",
    "druid": "#64b446",
    "hunter": "#50aaf0",
    "mage": "#b464f0"
  },
  "characters": {
    "druid": {
      "file": "characters/druid.png",
      "frameWidth": 96,
      "frameHeight": 96,
      "animations": {
        "idle": {
          "row": 0,
          "frames": 4,
          "fps": 6
        },
        "walk": {
          "row": 1,
          "frames": 4,
          "fps": 10
        },
        "attack": {
          "row": 2,
          "frames": 4,
          "fps": 12
        },
        "death": {
          "row": 3,
          "frames": 4,
          "fps": 8
        }
      }
    },
    "hunter": {
      "file": "characters/hunter.png",
      "frameWidth": 96,
      "frameHeight": 96,
      "animations": {
        "idle": {
          "row": 0,
          "frames": 4,
          "fps": 6
        },
        "walk": {
          "row": 1,
          "frames": 4,
          "fps": 10
        },
        "attack": {
          "row": 2,
          "frames": 4,
          "fps": 12
        },
        "death": {
          "row": 3,
          "frames": 4,
          "fps": 8
        }
      }
    },
    "mage": {
      "file": "characters/mage.png",
      "frameWidth": 96,
      "frameHeight": 96,
      "animations": {
        "idle": {
          "row": 0,
          "frames": 4,
          "fps": 6
        },
        "walk": {
          "row": 1,
          "frames": 4,
          "fps": 10
        },
        "attack": {
          "row": 2,
          "frames": 4,
          "fps": 12
        },
        "death": {
          "row": 3,
          "frames": 4,
          "fps": 8
        }
      }
    }
  },
  "enemies": {
    "skeleton": {
      "file": "enemies/skeleton.png",
      "walk": "enemies/skeleton_walk.png",
      "size": 64
    },
    "ghoul": {
      "file": "enemies/ghoul.png",
      "walk": "enemies/ghoul_walk.png",
      "size": 64
    },
    "hellhound": {
      "file": "enemies/hellhound.png",
      "walk": "enemies/hellhound_walk.png",
      "size": 64
    },
    "demonMage": {
      "file": "enemies/demonMage.png",
      "walk": "enemies/demonMage_walk.png",
      "size": 64
    },
    "fallenKnight": {
      "file": "enemies/fallenKnight.png",
      "walk": "enemies/fallenKnight_walk.png",
      "size": 64
    },
    "riftLord": {
      "file": "enemies/riftLord.png",
      "idle": "enemies/riftLord_idle.png",
      "size": 128
    }
  },
  "skillIcons": [
    {
      "id": "wolfSummon",
      "file": "skills/icons/wolfSummon.png",
      "size": 64
    },
    {
      "id": "pierceArrow",
      "file": "skills/icons/pierceArrow.png",
      "size": 64
    },
    {
      "id": "mageFireball",
      "file": "skills/icons/mageFireball.png",
      "size": 64
    },
    {
      "id": "frostRing",
      "file": "skills/icons/frostRing.png",
      "size": 64
    },
    {
      "id": "chainLightning",
      "file": "skills/icons/chainLightning.png",
      "size": 64
    },
    {
      "id": "meteor",
      "file": "skills/icons/meteor.png",
      "size": 64
    },
    {
      "id": "blackHole",
      "file": "skills/icons/blackHole.png",
      "size": 64
    },
    {
      "id": "arrowStorm",
      "file": "skills/icons/arrowStorm.png",
      "size": 64
    },
    {
      "id": "ancientNature",
      "file": "skills/icons/ancientNature.png",
      "size": 64
    },
    {
      "id": "apocalypse",
      "file": "skills/icons/apocalypse.png",
      "size": 64
    }
  ],
  "skillFX": [
    {
      "id": "slash",
      "file": "skills/fx/slash.png",
      "frameWidth": 128,
      "frames": 4,
      "fps": 12
    },
    {
      "id": "explosion",
      "file": "skills/fx/explosion.png",
      "frameWidth": 128,
      "frames": 4,
      "fps": 12
    },
    {
      "id": "lightning",
      "file": "skills/fx/lightning.png",
      "frameWidth": 128,
      "frames": 4,
      "fps": 12
    },
    {
      "id": "frost",
      "file": "skills/fx/frost.png",
      "frameWidth": 128,
      "frames": 4,
      "fps": 12
    },
    {
      "id": "poison",
      "file": "skills/fx/poison.png",
      "frameWidth": 128,
      "frames": 4,
      "fps": 12
    },
    {
      "id": "summonBurst",
      "file": "skills/fx/summonBurst.png",
      "frameWidth": 128,
      "frames": 4,
      "fps": 12
    },
    {
      "id": "meteorImpact",
      "file": "skills/fx/meteorImpact.png",
      "frameWidth": 128,
      "frames": 4,
      "fps": 12
    },
    {
      "id": "arrowRain",
      "file": "skills/fx/arrowRain.png",
      "frameWidth": 128,
      "frames": 4,
      "fps": 12
    }
  ],
  "tiles": [
    {
      "id": "stone",
      "file": "tiles/stone.png",
      "size": 128
    },
    {
      "id": "lava",
      "file": "tiles/lava.png",
      "size": 128
    },
    {
      "id": "crack",
      "file": "tiles/crack.png",
      "size": 128
    },
    {
      "id": "bones",
      "file": "tiles/bones.png",
      "size": 128
    }
  ],
  "ui": [
    {
      "id": "hp",
      "file": "ui/hp.png",
      "size": 48
    },
    {
      "id": "exp",
      "file": "ui/exp.png",
      "size": 48
    },
    {
      "id": "gold",
      "file": "ui/gold.png",
      "size": 48
    },
    {
      "id": "pause",
      "file": "ui/pause.png",
      "size": 48
    },
    {
      "id": "settings",
      "file": "ui/settings.png",
      "size": 48
    }
  ]
};
